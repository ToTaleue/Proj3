//
// Created by guestsh1 on 24-4-19.
//

#ifndef LAB12_STARTER_EXAMPLE_H
#define LAB12_STARTER_EXAMPLE_H

void draw();

#endif //LAB12_STARTER_EXAMPLE_H
